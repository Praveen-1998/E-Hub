import { Component, OnInit } from '@angular/core';
import { ManufacturerService } from '../manufacturer.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-dealer-list',
  templateUrl: './dealer-list.component.html',
  styleUrls: ['./dealer-list.component.css']
})
export class DealerListComponent implements OnInit {

  Dealers = {
    userId: null,
    userName: null,
    email: null,
    location: null
  };

  dealers: any[];
  constructor(private service: ManufacturerService) {
  this.getAllDealer();
  }

  getAllDealer() {
    this.service.viewAllDealer().subscribe(dealer => {
console.log(dealer);
this.dealers = dealer;
    }, err => {
      console.log(err);
    }, () => {
      console.log('completed successfully');
    });
  }

  editDealer(dealerDetails){
    this.Dealers = dealerDetails;
  }
  updateDealer(form: NgForm) {
this.service.updateDealer(form.value).subscribe(dealer => {
console.log(dealer);
} , err => {
  console.log(err);
}, () => {
  console.log('Dealer Updated Successfully');
});
  }
  deleteDealer(userId) {
    this.service.deleteDealer(userId).subscribe(data => {
      console.log(data);
      this.getAllDealer();
    }, err => {
      console.log(err);
    }, () => {
      console.log('deleted suuccesfully');
    });
  }


  ngOnInit() {
  }

}
