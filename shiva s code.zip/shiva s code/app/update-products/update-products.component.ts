import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManufacturerService } from '../manufacturer.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-products',
  templateUrl: './update-products.component.html',
  styleUrls: ['./update-products.component.css']
})
export class UpdateProductsComponent implements OnInit {
  
  constructor(private service: ManufacturerService, private router: Router) { }
  submitForm(form: NgForm) {
    this.service.updateProduct(form.value).subscribe(data => {
      console.log('hi');
      console.log(data);
    }, err => {
      console.log(err);
    });
  }

  ngOnInit() {
  }

  redirect() {
    this.router.navigateByUrl('/manufacturer');
  }
}
