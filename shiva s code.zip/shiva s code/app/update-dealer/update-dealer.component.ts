import { Component, OnInit } from '@angular/core';
import { ManufacturerService } from '../manufacturer.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-update-dealer',
  templateUrl: './update-dealer.component.html',
  styleUrls: ['./update-dealer.component.css']
})
export class UpdateDealerComponent implements OnInit {

  constructor(private service: ManufacturerService ) { }

  submitForm(form: NgForm) {
    this.service.updateDealer(form.value).subscribe(data => {
      console.log('hi');
      console.log(data);

    }, err => {
      console.log(err);
    });
  }


  ngOnInit() {
  }

}
