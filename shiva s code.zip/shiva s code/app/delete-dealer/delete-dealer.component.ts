import { Component, OnInit } from '@angular/core';
import { ManufacturerService } from '../manufacturer.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-delete-dealer',
  templateUrl: './delete-dealer.component.html',
  styleUrls: ['./delete-dealer.component.css']
})
export class DeleteDealerComponent implements OnInit {

  constructor(private service: ManufacturerService ) { }

  submitForm(form: NgForm) {
    this.service.deleteDealer(form.value).subscribe(data => {
      console.log('hi');
      console.log(data);

    }, err => {
      console.log(err);
    });
  }
  ngOnInit() {
  }

}
