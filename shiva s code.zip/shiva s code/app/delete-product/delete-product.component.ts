import { Component, OnInit } from '@angular/core';
import { ManufacturerService } from '../manufacturer.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-delete-product',
  templateUrl: './delete-product.component.html',
  styleUrls: ['./delete-product.component.css']
})
export class DeleteProductComponent implements OnInit {

  constructor(private service: ManufacturerService ) { }

  submitForm(form: NgForm) {
    this.service.deleteProduct(form.value).subscribe(data => {
      console.log(data);

    }, err => {
      console.log(err);
    });
  }

  ngOnInit() {
  }

}
