import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManufacturelistComponent } from './manufacturelist.component';

describe('ManufacturelistComponent', () => {
  let component: ManufacturelistComponent;
  let fixture: ComponentFixture<ManufacturelistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManufacturelistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManufacturelistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
