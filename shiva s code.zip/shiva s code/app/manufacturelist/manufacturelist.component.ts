import { Component, OnInit } from '@angular/core';
import { AdminService } from '../admin.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-manufacturelist',
  templateUrl: './manufacturelist.component.html',
  styleUrls: ['./manufacturelist.component.css']
})
export class ManufacturelistComponent implements OnInit {
  Manufactures = {
    userId: null,
    userName: null,
    email: null,
    location: null
  };

  manufactures: any[];
  constructor(private service: AdminService) {
    this.getAllManufacture();
  }

  getAllManufacture() {
    this.service.getAllManufacture().subscribe(manufacture => {
      console.log(manufacture);
      this.manufactures = manufacture;
    }, err => {
      console.log(err);
    }, () => {
      console.log('Got successfully');
    });
  }

  editManufacture(manufactureDetails) {
    this.Manufactures = manufactureDetails;
  }
  updateManufacture(form: NgForm) {
    this.service.modifyManufacturer(form.value).subscribe(manufacture => {
      console.log(manufacture);
    }, err => {
      console.log(err);
    }, () => {
      console.log('Manufacture Updated Successfully');
    });
  } ngOnInit() {
  }

}
