import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-update-manufacturer',
  templateUrl: './update-manufacturer.component.html',
  styleUrls: ['./update-manufacturer.component.css']
})
export class UpdateManufacturerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
