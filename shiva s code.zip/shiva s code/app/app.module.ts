import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { HomeComponent } from './home/home.component';
import { ManufacturerComponent } from './manufacturer/manufacturer.component';
//import { ProductsComponent } from './products/products.component';
import { StoreComponent } from './store/store.component';
import { LoginComponent } from './login/login.component';
import { ProductsComponent } from './products/products.component';
import { AddProductsComponent } from './add-products/add-products.component';
import { UpdateProductsComponent } from './update-products/update-products.component';
import { DeleteProductComponent } from './delete-product/delete-product.component';
import { AddDealerComponent } from './add-dealer/add-dealer.component';
import { UpdateDealerComponent } from './update-dealer/update-dealer.component';
import { DeleteDealerComponent } from './delete-dealer/delete-dealer.component';
import { DealerListComponent } from './dealer-list/dealer-list.component';
import { AdminComponent } from './admin/admin.component';
import { AddManufacturerComponent } from './add-manufacturer/add-manufacturer.component';
import { UpdateManufacturerComponent } from './update-manufacturer/update-manufacturer.component';
import { DeleteManufacturerComponent } from './delete-manufacturer/delete-manufacturer.component';
import { DealerComponent } from './dealer/dealer.component';
import { OrderListComponent } from './order-list/order-list.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { ShowallProductsComponent } from './showall-products/showall-products.component';
import { ProductformComponent } from './productform/productform.component';
import { HttpClientModule } from '@angular/common/http';
import { ManufacturelistComponent } from './manufacturelist/manufacturelist.component';
import { ViewMyStoreComponent } from './view-my-store/view-my-store.component';
import { ViewMyOrderComponent } from './view-my-order/view-my-order.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    HomeComponent,
    ManufacturerComponent,
   // ProductsComponent,
    StoreComponent,
    LoginComponent,
    ProductsComponent,
    AddProductsComponent,
    UpdateProductsComponent,
    DeleteProductComponent,
    AddDealerComponent,
    UpdateDealerComponent,
    DeleteDealerComponent,
    DealerListComponent,
    AdminComponent,
    AddManufacturerComponent,
    UpdateManufacturerComponent,
    DeleteManufacturerComponent,
    DealerComponent,
    OrderListComponent,
    ContactUsComponent,
    ShowallProductsComponent,
    ProductformComponent,
    ManufacturelistComponent,
    ViewMyStoreComponent,
    ViewMyOrderComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
     
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
