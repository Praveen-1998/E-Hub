import { Component, OnInit } from '@angular/core';
import { Product } from 'src/product';
import { Router } from '@angular/router';
import { DealerService } from '../dealer.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-showall-products',
  templateUrl: './showall-products.component.html',
  styleUrls: ['./showall-products.component.css']
})
export class ShowallProductsComponent implements OnInit {


  constructor(private service: DealerService, private router: Router) { this.showAllProducts(); }
  AllproductsShow: any[];

  Allproducts = {
    productId: null,

  }
  ngOnInit() {
  }
  showAllProducts() {
    this.service.showAllProducts().subscribe(data => {
      console.log(data);
      this.AllproductsShow = data;
    }, err => {
      console.log(err);
    }, () => {
      console.log('allproducts got successfully');
    }
    );
  }

  updateData(product) {
    this.Allproducts = product;
  }
  OrderProduct(form: NgForm) {
    this.service.orderProduct(form.value).subscribe(product => {
      this.service.showAllProducts();
    }, err => {
      console.log(err);
    }, () => {
      console.log('Ordered successfully');
    });
  }
  // redirect() {
  //   this.router.navigateByUrl('/productform')
  // }
}
