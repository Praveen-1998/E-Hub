import { Injectable } from '@angular/core';
import { HttpClient } from 'selenium-webdriver/http';
import { Product } from './product';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  api = '';
  products: Product[] = [];



  constructor(private http: HttpClient) { }
}

