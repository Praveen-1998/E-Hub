export class Employee {
    id: number;
    emp_name: string;
    emp_join_date: string;
    emp_experience: string;
    emp_adr:string;
    emp_salary: number;
    emp_age: number;
    emp_email: string;
    emp_dob: any;
}
